<template src="../views/Info.html">
    
</template>
<script>
export default {

}
</script>

<style>

</style>
