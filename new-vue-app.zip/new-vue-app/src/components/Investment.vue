<template src="../views/Investment.html">

</template>

<script>

</script>

<style>

</style>