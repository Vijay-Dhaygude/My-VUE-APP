# new-vue-app
This is a banking overview made in vuejs 

###**Install**

#The node version should be >=8

#Git clone or download the zip file.

###**To run the application**

#go to folder new-vue-app-master containing the package.json file 

#if cloned then do cd new-vue-app-master

#run 'npm install' --> for dependency download

#run 'npm run serve' --> for starting the server

###**Launch the application**

#open the localhost url on browser (shown after successfull 'npm run serve')

###**Test**

#run 'npm run test:unit'

